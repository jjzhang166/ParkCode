<?php
include_once __DIR__."/"."park_register.php";
include_once __DIR__."/"."park_credit.php";
include_once __DIR__."/"."park_time.php";
include_once __DIR__."/"."park_config.php";
include_once __DIR__."/"."park_user.php";
include_once __DIR__."/"."park_sort.php";
include_once __DIR__."/"."park_stay.php";
include_once __DIR__."/"."park_photo.php";
?>
